const STORAGE_KEY = 'tuoba-ultimate-all-in-one-v1';
const BRANDS = {
  'TUOBA Fried & Grill':['Giza Main','Nasr City'],
  'TUOBA Cafe':['Sheikh Zayed','New Cairo'],
  'TUOBA Express':['Alexandria']
};
const MENU = [
  {name:'برجر دجاج', price:85, prep:12},
  {name:'برجر لحم', price:95, prep:14},
  {name:'وجبة استربس', price:120, prep:15},
  {name:'فرايز', price:35, prep:6},
  {name:'كولا', price:25, prep:1},
  {name:'قهوة', price:45, prep:4}
];
const DELIVERY_LINKS = [
  {name:'Talabat', url:'https://www.talabat.com/egypt'},
  {name:'elmenus', url:'https://elmenus.com/'},
  {name:'Mrsool', url:'https://mrsool.co/'},
  {name:'Rabbit', url:'https://rabbitmart.com/'},
  {name:'HurryApp', url:'https://play.google.com/store/apps/details?id=com.tawaf.hurryapp'}
];
const DRIVERS = ['مندوب 1','مندوب 2','مندوب 3'];

const initialState = {
  brand:'TUOBA Fried & Grill',
  branch:'Giza Main',
  cart:[],
  currentMode:'table',
  currentTable:'T1',
  tables:[
    {id:'T1', occupied:false},{id:'T2', occupied:false},{id:'T3', occupied:false},
    {id:'T4', occupied:false},{id:'T5', occupied:false},{id:'T6', occupied:false}
  ],
  printer:{cashierCopies:1, kitchenCopies:1, pickupCopies:1},
  orders:[],
  expenses:[],
  recipes:[],
  geidea:[],
  finance:[
    {brand:'TUOBA Fried & Grill', branch:'Giza Main', foodCost:168000, payroll:95000, rent:40000, other:32000},
    {brand:'TUOBA Fried & Grill', branch:'Nasr City', foodCost:120000, payroll:70000, rent:35000, other:25000},
    {brand:'TUOBA Cafe', branch:'Sheikh Zayed', foodCost:90000, payroll:65000, rent:42000, other:22000},
    {brand:'TUOBA Cafe', branch:'New Cairo', foodCost:85000, payroll:60000, rent:40000, other:21000},
    {brand:'TUOBA Express', branch:'Alexandria', foodCost:70000, payroll:50000, rent:30000, other:18000}
  ],
  customerCalls:[],
  customers:[
    {brand:'TUOBA Fried & Grill', branch:'Giza Main', name:'عميل 1', phone:'01000000001', lastPayment:'NFC'}
  ],
  attendance:[],
  location:{lat:null,lng:null,label:'غير متاح'},
  shifts:[
    {name:'Morning', start:'09:00', end:'18:00'},
    {name:'Evening', start:'14:00', end:'23:00'}
  ],
  payments:[],
  securityLogs:[
    {brand:'TUOBA Fried & Grill', branch:'Giza Main', type:'login', detail:'Passkey login simulated', time:new Date().toLocaleString()}
  ]
};

function loadState(){ try{return JSON.parse(localStorage.getItem(STORAGE_KEY)) || structuredClone(initialState)}catch{return structuredClone(initialState)} }
let state = loadState();
function saveState(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }

const brandSelect = document.getElementById('brand-select');
const branchSelect = document.getElementById('branch-select');
const content = document.getElementById('content');
const buttons = document.querySelectorAll('.nav-btn');

function initSelectors(){
  brandSelect.innerHTML = Object.keys(BRANDS).map(b=>`<option value="${b}">${b}</option>`).join('');
  brandSelect.value = state.brand;
  updateBranches();
  brandSelect.onchange = ()=>{ state.brand = brandSelect.value; state.branch = BRANDS[state.brand][0]; saveState(); updateBranches(); render(currentTab); };
  branchSelect.onchange = ()=>{ state.branch = branchSelect.value; saveState(); render(currentTab); };
}
function updateBranches(){
  const arr = BRANDS[state.brand] || [];
  branchSelect.innerHTML = arr.map(b=>`<option value="${b}">${b}</option>`).join('');
  if(!arr.includes(state.branch)) state.branch = arr[0] || '';
  branchSelect.value = state.branch;
}
function scoped(arr){ return arr.filter(x=>x.brand===state.brand && x.branch===state.branch); }
function setActive(tab){ buttons.forEach(b=>b.classList.toggle('active', b.dataset.tab===tab)); }
function kpi(label, value, delta=''){ return `<div class="card"><div class="kpi-label">${label}</div><div class="kpi-value">${value}</div><div class="kpi-delta">${delta}</div></div>`; }
function minutesLeft(readyAt){ const diff = Math.ceil((new Date(readyAt).getTime() - Date.now())/60000); return diff > 0 ? diff : 0; }

function branchPL(brand, branch){
  const salesRec = state.geidea.find(x=>x.brand===brand && x.branch===branch);
  const fin = state.finance.find(x=>x.brand===brand && x.branch===branch) || {foodCost:0,payroll:0,rent:0,other:0};
  const sales = salesRec?.total || 0;
  const totalCost = Number(fin.foodCost||0)+Number(fin.payroll||0)+Number(fin.rent||0)+Number(fin.other||0);
  const profit = sales - totalCost;
  const margin = sales > 0 ? Math.round((profit / sales) * 100) : 0;
  return {sales, ...fin, totalCost, profit, margin};
}
function brandPL(brand){
  return (BRANDS[brand] || []).reduce((acc, branch)=>{
    const p = branchPL(brand, branch);
    acc.sales += p.sales; acc.foodCost += p.foodCost||0; acc.payroll += p.payroll||0; acc.rent += p.rent||0; acc.other += p.other||0; acc.totalCost += p.totalCost; acc.profit += p.profit;
    return acc;
  }, {sales:0,foodCost:0,payroll:0,rent:0,other:0,totalCost:0,profit:0});
}
function aiBrief(){
  const openOrders = scoped(state.orders).filter(o=>o.status!=='picked').length;
  const openCalls = scoped(state.customerCalls).filter(o=>o.status!=='delivered').length;
  const p = branchPL(state.brand, state.branch);
  const notes = [];
  if(openOrders) notes.push(`يوجد ${openOrders} طلبات POS مفتوحة.`);
  if(openCalls) notes.push(`يوجد ${openCalls} طلبات كول سنتر/دليفري مفتوحة.`);
  if(p.sales > 0) notes.push(`صافي ربح الفرع الحالي: ${p.profit.toFixed(2)}`);
  if(p.margin < 15 && p.sales > 0) notes.push('هامش الربح منخفض ويحتاج مراجعة.');
  if(!notes.length) notes.push('الوضع التشغيلي الحالي مستقر.');
  return notes;
}

function renderOverview(){
  const orders = scoped(state.orders);
  const calls = scoped(state.customerCalls);
  const payments = scoped(state.payments);
  const p = branchPL(state.brand, state.branch);
  content.innerHTML = `
    <div class="hero">
      <div class="section-title">Ultimate Master Dashboard</div>
      <div class="small">${state.brand} · ${state.branch}</div>
    </div>
    <div class="grid-2">
      ${kpi('POS Orders', orders.length, 'POS')}
      ${kpi('Call Center', calls.length, 'CC')}
      ${kpi('Payments', payments.length, 'Pay')}
      ${kpi('Customers', scoped(state.customers).length, 'CRM')}
      ${kpi('Sales', p.sales.toFixed(2), 'Finance')}
      ${kpi('Profit', p.profit.toFixed(2), 'P&L')}
    </div>
    <div class="card">
      <div class="section-title">AI Brief</div>
      <div class="list">${aiBrief().map(n=>`<div class="list-item">${n}</div>`).join('')}</div>
    </div>
  `;
}

function renderPOS(){
  const cartTotal = state.cart.reduce((a,b)=>a+(b.price*b.qty),0);
  content.innerHTML = `
    <div class="card">
      <div class="section-title">نوع الطلب</div>
      <div class="btn-row">
        <button class="btn ${state.currentMode==='table' ? 'primary' : 'soft'}" onclick="setOrderMode('table')">طاولات</button>
        <button class="btn ${state.currentMode==='takeaway' ? 'primary' : 'soft'}" onclick="setOrderMode('takeaway')">Take Away</button>
        <button class="btn ${state.currentMode==='delivery' ? 'primary' : 'soft'}" onclick="setOrderMode('delivery')">Delivery</button>
      </div>
    </div>
    ${state.currentMode==='table' ? `<div class="card"><div class="section-title">الطاولات</div><div class="table-grid">${state.tables.map(t=>`<button class="table-card ${t.occupied ? 'occupied' : ''}" onclick="selectTable('${t.id}')">${t.id}</button>`).join('')}</div><div class="note">الطاولة الحالية: ${state.currentTable}</div></div>` : ''}
    ${state.currentMode==='delivery' ? `<div class="card"><div class="section-title">بيانات التوصيل</div><div class="form-grid"><input id="customer-name" class="input" placeholder="اسم العميل" /><input id="customer-phone" class="input" placeholder="رقم الهاتف" /><input id="delivery-app" class="input" placeholder="اسم التطبيق / القناة" /><textarea id="delivery-address" class="textarea" placeholder="العنوان"></textarea></div></div>` : ''}
    <div class="card"><div class="section-title">المنيو</div><div class="menu-grid">${MENU.map((m, idx)=>`<button class="menu-btn" onclick="addToCart(${idx})"><strong>${m.name}</strong><div class="muted">${m.price} ج</div><div class="small">Prep ${m.prep} min</div></button>`).join('')}</div></div>
    <div class="card"><div class="section-title">السلة</div><div class="list">${state.cart.length ? state.cart.map((i,idx)=>`<div class="cart-row"><div><strong>${i.name}</strong><div class="muted">${i.qty} × ${i.price}</div></div><div><button class="btn soft" onclick="changeQty(${idx}, 1)">+</button><button class="btn soft" onclick="changeQty(${idx}, -1)">-</button></div></div>`).join('') : '<div class="muted">السلة فارغة</div>'}</div><div class="section-title">الإجمالي: ${cartTotal.toFixed(2)} ج</div><div class="btn-row"><button class="btn soft" onclick="clearCart()">مسح</button><button class="btn primary" onclick="placeOrder('cash')">كاش</button><button class="btn primary" onclick="placeOrder('card')">فيزا</button></div></div>
  `;
}
function addToCart(idx){ const item = MENU[idx]; const existing = state.cart.find(x=>x.name===item.name); if(existing) existing.qty += 1; else state.cart.push({...item, qty:1}); saveState(); render('pos'); }
function changeQty(idx, delta){ if(!state.cart[idx]) return; state.cart[idx].qty += delta; if(state.cart[idx].qty <= 0) state.cart.splice(idx,1); saveState(); render('pos'); }
function clearCart(){ state.cart = []; saveState(); render('pos'); }
function setOrderMode(mode){ state.currentMode = mode; saveState(); render('pos'); }
function selectTable(id){ state.currentTable = id; saveState(); render('pos'); }
function placeOrder(payment){
  if(!state.cart.length) return alert('السلة فارغة');
  let customer = {};
  if(state.currentMode==='delivery'){
    customer = {
      name: document.getElementById('customer-name')?.value.trim() || '',
      phone: document.getElementById('customer-phone')?.value.trim() || '',
      app: document.getElementById('delivery-app')?.value.trim() || '',
      address: document.getElementById('delivery-address')?.value.trim() || ''
    };
    if(customer.phone) upsertCustomer(customer.name || 'عميل POS', customer.phone, payment);
  }
  const orderNo = 'ORD-' + Math.floor(Date.now()/1000);
  const prepMinutes = Math.max(...state.cart.map(i => i.prep), 5);
  const total = state.cart.reduce((a,b)=>a+(b.price*b.qty),0);
  state.orders.unshift({
    brand: state.brand, branch: state.branch, orderNo, mode: state.currentMode, table: state.currentMode==='table' ? state.currentTable : '',
    customer, payment, items: JSON.parse(JSON.stringify(state.cart)), total, prepMinutes,
    createdAt: new Date().toISOString(), readyAt: new Date(Date.now() + prepMinutes*60000).toISOString(), status:'preparing',
    cashierCopies: Number(state.printer.cashierCopies||1), kitchenCopies: Number(state.printer.kitchenCopies||1), pickupCopies: Number(state.printer.pickupCopies||1)
  });
  if(state.currentMode==='table'){ const t = state.tables.find(x=>x.id===state.currentTable); if(t) t.occupied = true; }
  state.cart = [];
  saveState(); render('orders');
}

function renderOrders(){
  const posOrders = scoped(state.orders);
  content.innerHTML = `
    <div class="card"><div class="section-title">طلبات POS</div><div class="list">${posOrders.length ? posOrders.map((o,idx)=>`
      <div class="list-item">
        <span class="badge ${o.status==='preparing' ? 'preparing' : o.status==='ready' ? 'ready' : 'picked'}">${o.status}</span>
        <div><strong>${o.orderNo}</strong> — ${o.mode} — ${o.total.toFixed(2)} ج</div>
        <div class="muted">${o.table ? 'Table: '+o.table+' — ' : ''}Prep: ${o.prepMinutes} min — Left: ${minutesLeft(o.readyAt)} min</div>
        <div class="small">Cashier: ${o.cashierCopies} · Kitchen: ${o.kitchenCopies} · Pickup: ${o.pickupCopies}</div>
        <div class="btn-row"><button class="btn soft" onclick="setPosOrderStatus(${idx}, 'preparing')">Preparing</button><button class="btn soft" onclick="setPosOrderStatus(${idx}, 'ready')">Ready</button><button class="btn soft" onclick="setPosOrderStatus(${idx}, 'picked')">Picked</button></div>
      </div>`).join('') : '<div class="muted">لا توجد طلبات</div>'}</div></div>
  `;
}
function setPosOrderStatus(idx, status){
  const orders = scoped(state.orders);
  const target = orders[idx];
  if(!target) return;
  const realIdx = state.orders.findIndex(x=>x===target);
  state.orders[realIdx].status = status;
  if(status==='picked' && target.mode==='table' && target.table){ const t = state.tables.find(x=>x.id===target.table); if(t) t.occupied = false; }
  saveState(); render('orders');
}

function renderKDS(){
  const orders = scoped(state.orders).filter(o=>o.status==='preparing');
  content.innerHTML = `<div class="card"><div class="section-title">Kitchen Display Screen</div><div class="list">${orders.length ? orders.map(o=>`
    <div class="list-item"><span class="badge preparing">PREPARING</span><div><strong>${o.orderNo}</strong> — ${o.mode}</div><div class="muted">Prep: ${o.prepMinutes} min — Left: ${minutesLeft(o.readyAt)} min</div><div class="list">${o.items.map(i=>`<div class="small">${i.qty} × ${i.name}</div>`).join('')}</div></div>`).join('') : '<div class="muted">لا توجد طلبات تحت التجهيز</div>'}</div></div>`;
}

function renderPickup(){
  const orders = scoped(state.orders).filter(o=>o.status==='ready');
  content.innerHTML = `<div class="card"><div class="section-title">Pickup Screen</div><div class="list">${orders.length ? orders.map(o=>`
    <div class="list-item"><span class="badge ready">READY</span><div><strong>${o.orderNo}</strong></div><div class="muted">${o.mode} ${o.customer?.name ? '— '+o.customer.name : ''}</div><div class="small">Pickup copies: ${o.pickupCopies}</div></div>`).join('') : '<div class="muted">لا توجد طلبات جاهزة</div>'}</div></div>`;
}

function renderApps(){
  content.innerHTML = `<div class="card"><div class="section-title">روابط تطبيقات البيع الأخرى</div><div class="channel-grid">${DELIVERY_LINKS.map(x=>`<a class="link-btn" href="${x.url}" target="_blank" rel="noopener noreferrer"><strong>${x.name}</strong><div class="muted">فتح الرابط</div></a>`).join('')}</div></div>`;
}

function renderPrinting(){
  content.innerHTML = `
    <div class="card"><div class="section-title">إعدادات الطباعة</div><div class="form-grid">
      <input id="cashier-copies" class="input" type="number" min="1" value="${state.printer.cashierCopies}" placeholder="عدد نسخ الكاشير" />
      <input id="kitchen-copies" class="input" type="number" min="1" value="${state.printer.kitchenCopies}" placeholder="عدد نسخ المطبخ" />
      <input id="pickup-copies" class="input" type="number" min="1" value="${state.printer.pickupCopies}" placeholder="عدد نسخ البيك أب" />
      <button class="btn primary" onclick="savePrinterSettings()">حفظ إعدادات الطباعة</button>
    </div></div>
  `;
}
function savePrinterSettings(){
  state.printer.cashierCopies = Math.max(1, Number(document.getElementById('cashier-copies').value || 1));
  state.printer.kitchenCopies = Math.max(1, Number(document.getElementById('kitchen-copies').value || 1));
  state.printer.pickupCopies = Math.max(1, Number(document.getElementById('pickup-copies').value || 1));
  saveState(); render('printing');
}

async function readImage(file){
  return new Promise((resolve) => {
    const r = new FileReader(); r.onload = ()=>resolve(r.result || ''); r.onerror = ()=>resolve(''); r.readAsDataURL(file);
  });
}
async function handleReceiptPreview(e){
  const file = e.target.files?.[0];
  const box = document.getElementById('receipt-preview-wrap');
  if(!file || !box) return;
  const src = await readImage(file);
  box.innerHTML = `<div class="small">اسم الصورة: ${file.name}</div><img src="${src}" style="width:100%;max-height:180px;object-fit:contain;border:1px solid #e2e8f0;border-radius:14px;padding:6px;background:#fff">`;
}
function renderExpenses(){
  const items = scoped(state.expenses);
  content.innerHTML = `
    <div class="card"><div class="section-title">إضافة مصروف / استلام</div><div class="form-grid">
      <input id="exp-title" class="input" placeholder="اسم المصروف أو الاستلام" />
      <input id="exp-amount" class="input" type="number" placeholder="المبلغ" />
      <input id="exp-receipt" class="input" type="file" accept="image/*" capture="environment" />
      <div id="receipt-preview-wrap" class="note">أضف صورة الاستلام أو الفاتورة</div>
      <textarea id="exp-note" class="textarea" placeholder="ملاحظات"></textarea>
      <button class="btn primary" onclick="addExpense()">حفظ السجل</button>
    </div></div>
    <div class="card"><div class="section-title">سجل المصروفات</div><div class="list">${items.length ? items.map(e=>`<div class="list-item"><strong>${e.title}</strong> — ${e.amount}<div class="muted">${e.note||''}</div>${e.receiptName ? `<div class="small">صورة: ${e.receiptName}</div>` : ''}</div>`).join('') : '<div class="muted">لا توجد بيانات</div>'}</div></div>
  `;
  document.getElementById('exp-receipt').addEventListener('change', handleReceiptPreview);
}
async function addExpense(){
  const title = document.getElementById('exp-title').value.trim();
  const amount = document.getElementById('exp-amount').value.trim();
  const note = document.getElementById('exp-note').value.trim();
  const receipt = document.getElementById('exp-receipt').files?.[0];
  if(!title || !amount) return alert('أدخل البيانات المطلوبة');
  state.expenses.unshift({brand:state.brand, branch:state.branch, title, amount, note, receiptName: receipt ? receipt.name : ''});
  saveState(); render('expenses');
}

function renderRecipe(){
  const items = scoped(state.recipes);
  content.innerHTML = `
    <div class="card"><div class="section-title">إضافة ريسيبي</div><div class="form-grid">
      <input id="r-name" class="input" placeholder="اسم الصنف / الوصفة" />
      <input id="r-cost" class="input" type="number" placeholder="تكلفة الوصفة" />
      <input id="r-price" class="input" type="number" placeholder="سعر البيع" />
      <textarea id="r-ing" class="textarea" placeholder="المكونات"></textarea>
      <button class="btn primary" onclick="addRecipe()">حفظ الريسيبي</button>
    </div></div>
    <div class="card"><div class="section-title">Recipe Intelligence</div><div class="list">${items.length ? items.map(r=>`<div class="list-item"><span class="badge ${Number(r.margin)>=40?'good':'pending'}">${r.margin}%</span><div><strong>${r.name}</strong></div><div class="muted">التكلفة: ${r.cost} — السعر: ${r.price}</div></div>`).join('') : '<div class="muted">لا توجد وصفات بعد.</div>'}</div></div>
  `;
}
function addRecipe(){
  const name = document.getElementById('r-name').value.trim();
  const cost = Number(document.getElementById('r-cost').value || 0);
  const price = Number(document.getElementById('r-price').value || 0);
  const ingredients = document.getElementById('r-ing').value.trim();
  if(!name || !cost || !price) return alert('أدخل اسم الوصفة والتكلفة والسعر');
  const margin = price > 0 ? Math.round(((price - cost) / price) * 100) : 0;
  state.recipes.unshift({brand:state.brand, branch:state.branch, name, cost, price, ingredients, margin});
  saveState(); render('recipe');
}

let geideaHeaders = [], geideaRows = [];
function parseCSV(text){
  const lines = text.split(/\r?\n/).filter(Boolean);
  if(!lines.length) return {headers:[], rows:[]};
  const parseLine = (line) => {
    const out=[]; let cur=''; let inQuotes=false;
    for(let i=0;i<line.length;i++){
      const ch=line[i];
      if(ch === '"'){ if(inQuotes && line[i+1] === '"'){ cur += '"'; i++; } else inQuotes = !inQuotes; }
      else if(ch === ',' && !inQuotes){ out.push(cur.trim()); cur=''; } else cur += ch;
    }
    out.push(cur.trim()); return out;
  };
  const headers = parseLine(lines[0]).map(h=>h.replace(/^"|"$/g,'').trim());
  const rows = lines.slice(1).map(line => { const vals = parseLine(line); const obj={}; headers.forEach((h,i)=>obj[h]=(vals[i]||'').replace(/^"|"$/g,'').trim()); return obj; });
  return {headers, rows};
}
function normalize(s){ return String(s || '').toLowerCase().replace(/[_\-\s]+/g,''); }
function renderGeidea(){
  content.innerHTML = `
    <div class="card"><div class="section-title">رفع ملف جيديا CSV</div><input id="file-input" class="input" type="file" accept=".csv,text/csv" /><div class="note">ارفع ملف CSV رسمي من جيديا.</div></div>
    <div class="card"><div class="section-title">الأعمدة</div><div id="columns-box" class="muted">لم يتم رفع ملف بعد.</div></div>
    <div class="card"><div class="section-title">ربط الأعمدة</div><div class="form-grid">
      <label>التاريخ <select id="map-date" class="select"></select></label>
      <label>الوقت <select id="map-time" class="select"></select></label>
      <label>المبلغ <select id="map-amount" class="select"></select></label>
    </div><div class="btn-row"><button class="btn soft" onclick="autoMap()">ربط تلقائي</button><button class="btn primary" onclick="runImport()">استيراد</button></div></div>
    <div class="card"><div class="section-title">نتائج الاستيراد</div><div id="results-box" class="muted">لا توجد نتائج بعد.</div></div>
  `;
  document.getElementById('file-input').addEventListener('change', async (e)=>{
    const file = e.target.files?.[0]; if(!file) return;
    const parsed = parseCSV(await file.text()); geideaHeaders = parsed.headers; geideaRows = parsed.rows;
    fillMapSelects(); renderHeaders(); autoMap();
  });
}
function fillMapSelects(){ ['map-date','map-time','map-amount'].forEach(id => { const sel = document.getElementById(id); sel.innerHTML = '<option value="">--</option>' + geideaHeaders.map(h => `<option value="${h}">${h}</option>`).join(''); }); }
function renderHeaders(){ document.getElementById('columns-box').innerHTML = geideaHeaders.length ? geideaHeaders.map(h => `<div class="list-item">${h}</div>`).join('') : '—'; }
function autoMap(){ const guess = (patterns) => geideaHeaders.find(h => patterns.some(p => normalize(h).includes(p))); document.getElementById('map-date').value = guess(['date','تاريخ']) || ''; document.getElementById('map-time').value = guess(['time','وقت']) || ''; document.getElementById('map-amount').value = guess(['amount','total','gross','net','مبلغ','قيمة']) || ''; }
function runImport(){
  const amountCol = document.getElementById('map-amount').value;
  if(!amountCol) return alert('اختر عمود المبلغ');
  const cleaned = geideaRows.map(r => ({amount: Number(String(r[amountCol] || '0').replace(/[^0-9.\-]/g,'')) || 0}));
  const total = cleaned.reduce((a,b)=>a+b.amount,0);
  const count = cleaned.length;
  const avg = count ? total / count : 0;
  const idx = state.geidea.findIndex(x=>x.brand===state.brand && x.branch===state.branch);
  const rec = {brand:state.brand, branch:state.branch, total, count, avg};
  if(idx >= 0) state.geidea[idx] = rec; else state.geidea.unshift(rec);
  saveState();
  document.getElementById('results-box').innerHTML = `<div class="list"><div class="list-item">إجمالي المبيعات: ${total.toFixed(2)}</div><div class="list-item">عدد العمليات: ${count}</div><div class="list-item">متوسط العملية: ${avg.toFixed(2)}</div></div>`;
}

function renderFinance(){
  const p = branchPL(state.brand, state.branch);
  const b = brandPL(state.brand);
  const cIn = p.sales, cOut = p.totalCost, balance = p.sales - p.totalCost;
  const bMargin = b.sales > 0 ? Math.round((b.profit/b.sales)*100) : 0;
  content.innerHTML = `
    <div class="card"><div class="section-title">Branch P&L — ${state.branch}</div><div class="list">
      <div class="list-item">Sales: ${p.sales.toFixed(2)}</div>
      <div class="list-item">Food Cost: ${p.foodCost}</div>
      <div class="list-item">Payroll: ${p.payroll}</div>
      <div class="list-item">Rent: ${p.rent}</div>
      <div class="list-item">Other: ${p.other}</div>
      <div class="list-item"><strong>Net Profit: ${p.profit.toFixed(2)}</strong></div>
      <div class="list-item"><strong>Margin: ${p.margin}%</strong></div>
    </div></div>
    <div class="card"><div class="section-title">Brand P&L — ${state.brand}</div><div class="list">
      <div class="list-item">Sales: ${b.sales.toFixed(2)}</div>
      <div class="list-item">Total Cost: ${b.totalCost.toFixed(2)}</div>
      <div class="list-item"><strong>Profit: ${b.profit.toFixed(2)}</strong></div>
      <div class="list-item"><strong>Margin: ${bMargin}%</strong></div>
    </div></div>
    <div class="card"><div class="section-title">Cash Flow</div><div class="list"><div class="list-item">Cash In: ${cIn.toFixed(2)}</div><div class="list-item">Cash Out: ${cOut.toFixed(2)}</div><div class="list-item"><strong>Balance: ${balance.toFixed(2)}</strong></div></div></div>
  `;
}

function renderCallCenter(){
  const calls = scoped(state.customerCalls);
  content.innerHTML = `
    <div class="card"><div class="section-title">إنشاء طلب كول سنتر</div><div class="form-grid">
      <input id="cc-phone" class="input" placeholder="رقم العميل" />
      <input id="cc-name" class="input" placeholder="اسم العميل" />
      <select id="cc-type" class="select"><option value="delivery">Delivery</option><option value="takeaway">Take Away</option><option value="table">Table</option></select>
      <input id="cc-zone" class="input" placeholder="المنطقة / الزون" />
      <textarea id="cc-order" class="textarea" placeholder="تفاصيل الطلب"></textarea>
      <input id="cc-prep" class="input" type="number" placeholder="وقت التجهيز بالدقائق" value="20" />
      <button class="btn primary" onclick="createCallOrder()">حفظ الطلب</button>
    </div></div>
    <div class="card"><div class="section-title">لوحة الطلبات</div><div class="list">${calls.length ? calls.map((o,idx)=>`
      <div class="list-item"><span class="badge ${o.status==='new'?'pending':o.status==='assigned'?'pending':o.status==='out'?'preparing':'ready'}">${o.status}</span>
        <div><strong>${o.customerName}</strong> — ${o.phone}</div>
        <div class="muted">${o.orderText}</div>
        <div class="small">Driver: ${o.driver || '-'} · Prep left: ${minutesLeft(o.readyAt)} min</div>
        <div class="btn-row"><button class="btn soft" onclick="assignDriverPrompt(${idx})">Assign</button><button class="btn soft" onclick="setCallStatus(${idx}, 'out')">Out</button><button class="btn soft" onclick="setCallStatus(${idx}, 'delivered')">Done</button></div>
      </div>`).join('') : '<div class="muted">لا توجد طلبات بعد</div>'}</div></div>
  `;
}
function createCallOrder(){
  const phone = document.getElementById('cc-phone').value.trim();
  const customerName = document.getElementById('cc-name').value.trim();
  const type = document.getElementById('cc-type').value;
  const zone = document.getElementById('cc-zone').value.trim();
  const orderText = document.getElementById('cc-order').value.trim();
  const prep = Number(document.getElementById('cc-prep').value || 20);
  if(!phone || !customerName || !orderText) return alert('أدخل البيانات المطلوبة');
  const order = { brand: state.brand, branch: state.branch, id: 'CC-' + Math.floor(Date.now()/1000), phone, customerName, type, zone, orderText, status:'new', driver:'', createdAt: new Date().toISOString(), readyAt: new Date(Date.now() + prep*60000).toISOString() };
  state.customerCalls.unshift(order); upsertCustomer(customerName, phone, 'CC'); saveState(); render('callcenter');
}
function assignDriverPrompt(idx){
  const driver = prompt('اختر المندوب:\n' + DRIVERS.join('\n'), DRIVERS[0]); if(!driver) return;
  const orders = scoped(state.customerCalls); const target = orders[idx]; if(!target) return;
  const realIdx = state.customerCalls.findIndex(x => x === target); state.customerCalls[realIdx].driver = driver; state.customerCalls[realIdx].status = 'assigned'; saveState(); render('callcenter');
}
function setCallStatus(idx, status){
  const orders = scoped(state.customerCalls); const target = orders[idx]; if(!target) return;
  const realIdx = state.customerCalls.findIndex(x => x === target); state.customerCalls[realIdx].status = status; saveState(); render('callcenter');
}

function renderCRM(){
  const customers = scoped(state.customers);
  content.innerHTML = `<div class="card"><div class="section-title">CRM العملاء لهذا البراند فقط</div><div class="list">${customers.length ? customers.map(c=>`<div class="list-item"><div><strong>${c.name}</strong> — ${c.phone}</div><div class="muted">Last payment/source: ${c.lastPayment || '-'}</div></div>`).join('') : '<div class="muted">لا توجد بيانات</div>'}</div></div>`;
}
function upsertCustomer(name, phone, lastPayment){
  const idx = state.customers.findIndex(x=>x.brand===state.brand && x.phone===phone);
  if(idx >= 0){ state.customers[idx].name = name; state.customers[idx].lastPayment = lastPayment; }
  else state.customers.push({brand:state.brand, branch:state.branch, name, phone, lastPayment});
}

function renderAttendance(){
  const rows = scoped(state.attendance);
  content.innerHTML = `
    <div class="card"><div class="section-title">Attendance by location</div><div class="muted">Current location: ${state.location.label}</div><div class="form-grid">
      <input id="emp-name" class="input" placeholder="اسم الموظف" />
      <select id="emp-shift" class="select">${state.shifts.map(s=>`<option value="${s.name}">${s.name} (${s.start}-${s.end})</option>`).join('')}</select>
      <div class="btn-row"><button class="btn primary" onclick="checkIn()">حضور</button><button class="btn soft" onclick="checkOut()">انصراف</button><button class="btn soft" onclick="getCurrentLocation()">تحديث الموقع</button></div>
    </div></div>
    <div class="card"><div class="section-title">سجل الحضور</div><div class="list">${rows.length ? rows.map(r=>`<div class="list-item"><div><strong>${r.employee}</strong> — ${r.shift}</div><div class="muted">In: ${r.checkInAt || '-'} · Out: ${r.checkOutAt || '-'}</div><div class="small">Hours: ${r.hoursWorked || 0} · Overtime: ${r.overtime || 0}</div></div>`).join('') : '<div class="muted">لا توجد حركات حضور بعد</div>'}</div></div>
  `;
}
function getCurrentLocation(){
  if(!navigator.geolocation){ state.location = {lat:null,lng:null,label:'المتصفح لا يدعم الموقع'}; saveState(); render(currentTab); return; }
  navigator.geolocation.getCurrentPosition((pos)=>{ state.location = { lat: pos.coords.latitude, lng: pos.coords.longitude, label: `${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}` }; saveState(); render(currentTab); }, ()=>{ state.location = {lat:null,lng:null,label:'تعذر قراءة الموقع'}; saveState(); render(currentTab); });
}
function checkIn(){
  const employee = document.getElementById('emp-name').value.trim(); const shift = document.getElementById('emp-shift').value; if(!employee) return alert('أدخل اسم الموظف');
  state.attendance.unshift({ brand:state.brand, branch:state.branch, employee, shift, checkInAt:new Date().toLocaleString(), checkOutAt:'', location:state.location.label, hoursWorked:0, overtime:0 });
  saveState(); render('attendance');
}
function checkOut(){
  const employee = document.getElementById('emp-name').value.trim(); if(!employee) return alert('أدخل اسم الموظف');
  const idx = state.attendance.findIndex(x=>x.brand===state.brand && x.branch===state.branch && x.employee===employee && !x.checkOutAt); if(idx < 0) return alert('لا يوجد حضور مفتوح لهذا الموظف');
  state.attendance[idx].checkOutAt = new Date().toLocaleString(); state.attendance[idx].hoursWorked = 9; state.attendance[idx].overtime = 1; saveState(); render('attendance');
}

function renderPayments(){
  const payments = scoped(state.payments);
  content.innerHTML = `
    <div class="card"><div class="section-title">إنشاء عملية دفع</div><div class="form-grid">
      <input id="pay-customer" class="input" placeholder="اسم العميل" />
      <input id="pay-phone" class="input" placeholder="رقم الهاتف" />
      <input id="pay-amount" class="input" type="number" placeholder="المبلغ" />
      <select id="pay-method" class="select">
        <option value="NFC">NFC / Contactless</option>
        <option value="Card">Card</option>
        <option value="QR">QR</option>
        <option value="Cash">Cash</option>
        <option value="Wallet">Wallet</option>
        <option value="Split">Split</option>
      </select>
      <button class="btn primary" onclick="createPayment()">تسجيل العملية</button>
    </div></div>
    <div class="card"><div class="section-title">سجل المدفوعات</div><div class="list">${payments.length ? payments.map(p=>`<div class="list-item"><span class="badge good">${p.method}</span><div><strong>${p.customer}</strong> — ${p.amount}</div><div class="muted">${p.phone} · ${p.txId}</div></div>`).join('') : '<div class="muted">لا توجد عمليات بعد</div>'}</div></div>
  `;
}
function createPayment(){
  const customer = document.getElementById('pay-customer').value.trim();
  const phone = document.getElementById('pay-phone').value.trim();
  const amount = Number(document.getElementById('pay-amount').value || 0);
  const method = document.getElementById('pay-method').value;
  if(!customer || !phone || !amount) return alert('أدخل البيانات المطلوبة');
  const txId = 'TX-' + Math.floor(Date.now()/1000);
  state.payments.unshift({brand:state.brand, branch:state.branch, customer, phone, amount, method, txId});
  upsertCustomer(customer, phone, method);
  state.securityLogs.unshift({brand:state.brand, branch:state.branch, type:'payment', detail:`${method} payment ${txId}`, time:new Date().toLocaleString()});
  saveState(); render('payments');
}

function renderSecurity(){
  const logs = scoped(state.securityLogs);
  content.innerHTML = `
    <div class="card"><div class="section-title">طبقات الأمان داخل النسخة</div><div class="list">
      <div class="list-item"><span class="badge sec">Passkey/Biometric</span> تسجيل دخول حديث.</div>
      <div class="list-item"><span class="badge sec">Brand isolation</span> فصل عرض العملاء والمدفوعات حسب البراند.</div>
      <div class="list-item"><span class="badge sec">Audit logs</span> تتبع العمليات الحساسة.</div>
      <div class="list-item"><span class="badge warn">MVP</span> النسخة الحالية نموذج أولي محلي وليست تكاملًا بنكيًا مباشرًا.</div>
    </div></div>
    <div class="card"><div class="section-title">السجلات الأمنية</div><div class="list">${logs.length ? logs.map(l=>`<div class="list-item"><div><strong>${l.type}</strong></div><div class="muted">${l.detail}</div><div class="small">${l.time}</div></div>`).join('') : '<div class="muted">لا توجد سجلات</div>'}</div></div>
  `;
}
function simulateBiometric(){
  state.securityLogs.unshift({brand:state.brand, branch:state.branch, type:'login', detail:'Passkey/biometric simulated', time:new Date().toLocaleString()});
  saveState(); alert('تمت محاكاة تسجيل دخول ببصمة/Passkey'); render('security');
}

function renderReports(){
  const orders = scoped(state.orders);
  const calls = scoped(state.customerCalls);
  const payments = scoped(state.payments);
  const brandSummary = brandPL(state.brand);
  const brandMargin = brandSummary.sales > 0 ? Math.round((brandSummary.profit / brandSummary.sales) * 100) : 0;
  content.innerHTML = `
    <div class="hero"><div class="section-title">Integrated Reports</div><div class="small">${state.brand}</div></div>
    <div class="grid-2">
      ${kpi('POS Orders', orders.length, 'POS')}
      ${kpi('CC Orders', calls.length, 'CC')}
      ${kpi('Payments', payments.length, 'Pay')}
      ${kpi('Brand Margin', brandMargin + '%', 'Brand')}
    </div>
    <div class="card"><div class="section-title">AI Brief</div><div class="list">${aiBrief().map(n=>`<div class="list-item">${n}</div>`).join('')}</div></div>
  `;
}

function exportData(){
  const blob = new Blob([JSON.stringify(state, null, 2)], {type:'application/json'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'tuoba-ultimate-all-in-one-data.json'; a.click();
}

let currentTab = 'overview';
function render(tab){
  currentTab = tab; setActive(tab);
  if(tab==='overview') renderOverview();
  if(tab==='pos') renderPOS();
  if(tab==='orders') renderOrders();
  if(tab==='kds') renderKDS();
  if(tab==='pickup') renderPickup();
  if(tab==='apps') renderApps();
  if(tab==='printing') renderPrinting();
  if(tab==='expenses') renderExpenses();
  if(tab==='recipe') renderRecipe();
  if(tab==='geidea') renderGeidea();
  if(tab==='finance') renderFinance();
  if(tab==='callcenter') renderCallCenter();
  if(tab==='crm') renderCRM();
  if(tab==='attendance') renderAttendance();
  if(tab==='payments') renderPayments();
  if(tab==='security') renderSecurity();
  if(tab==='reports') renderReports();
}
buttons.forEach(btn=>btn.addEventListener('click', ()=>render(btn.dataset.tab)));

window.setOrderMode = setOrderMode;
window.selectTable = selectTable;
window.addToCart = addToCart;
window.changeQty = changeQty;
window.clearCart = clearCart;
window.placeOrder = placeOrder;
window.setPosOrderStatus = setPosOrderStatus;
window.savePrinterSettings = savePrinterSettings;
window.addExpense = addExpense;
window.addRecipe = addRecipe;
window.autoMap = autoMap;
window.runImport = runImport;
window.createCallOrder = createCallOrder;
window.assignDriverPrompt = assignDriverPrompt;
window.setCallStatus = setCallStatus;
window.getCurrentLocation = getCurrentLocation;
window.checkIn = checkIn;
window.checkOut = checkOut;
window.createPayment = createPayment;
window.simulateBiometric = simulateBiometric;
window.exportData = exportData;

if('serviceWorker' in navigator){ navigator.serviceWorker.register('./sw.js').catch(()=>{}); }
initSelectors();
render('overview');
