# HR Notes

- Check-in / Check-out
- Location capture from browser
- Shift selection
- Worked hours
- Overtime
- Attendance records
