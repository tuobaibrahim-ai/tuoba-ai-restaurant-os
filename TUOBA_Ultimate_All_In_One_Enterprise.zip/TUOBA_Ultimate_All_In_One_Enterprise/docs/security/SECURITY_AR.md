# Security Notes

## النسخة الحالية
- Security logs
- Simulated passkey / biometric
- Brand-isolated customer views
- Exportable data for review

## النسخة السحابية المثالية لاحقًا
- Passkeys / biometrics
- RLS
- Device trust
- Audit logs
- Central monitoring
- Payment connector isolation
