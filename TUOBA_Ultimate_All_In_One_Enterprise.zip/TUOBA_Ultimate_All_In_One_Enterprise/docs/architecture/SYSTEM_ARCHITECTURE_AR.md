# System Architecture

## الطبقات
- Operations Layer
- POS Layer
- Delivery & Call Center Layer
- Finance Layer
- HR Layer
- Quality Layer
- Security Layer
- Payment Layer

## العزل
- Brand isolation
- Branch context
- Role-ready structure

## النسخة السحابية لاحقًا
- Multi-tenant database
- API auth
- Passkeys/WebAuthn
- RLS
- Payment connectors
- Realtime modules
