# Finance Notes

- Branch P&L
- Brand P&L
- Cash Flow
- Food cost
- Payroll
- Rent
- Other expenses
- Prime cost logic ready conceptually
