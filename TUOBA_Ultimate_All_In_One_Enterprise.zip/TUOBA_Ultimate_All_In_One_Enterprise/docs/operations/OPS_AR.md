# Operations Notes

- POS order modes
- KDS
- Pickup
- Driver assignment
- Call center order creation
- Customer CRM
- Delivery channel reference links
- Printer copy settings
