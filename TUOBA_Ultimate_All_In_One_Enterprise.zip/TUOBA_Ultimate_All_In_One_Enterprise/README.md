# TUOBA Ultimate All-in-One Enterprise

نسخة موحدة شاملة تجمع في نظام واحد:

- Executive Dashboard
- Multi-brand / Multi-branch
- POS
- Tables / Take Away / Delivery
- KDS / Pickup
- Delivery apps quick links
- Printing controls
- Expenses & receipts
- Geidea CSV import
- Recipes / food cost / margin
- Finance Center
- Branch P&L
- Brand P&L
- Cash Flow
- Call Center
- Customer CRM
- HR / Attendance / Overtime
- Quality / SOP / HACCP / Hygiene
- Payment Engine prototype
- NFC / Card / QR / Cash / Wallet / Split
- Brand-isolated customer views
- Security logs / passkey simulation
- Portable / PWA-ready

## التشغيل
افتح:
`app/index.html`
